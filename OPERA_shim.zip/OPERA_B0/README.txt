How to get started / General description of workflow

1. Use Python Script squares//build_coil_opera.py to generate the comi files corresponding to each of the 54 coils
2. The comi files are saved/written to the comi folder
3. To run any individual comi file, simply open the GUI and run the desired specific comi file
4. When running any comi file, an op3 file and opc file will be generated. The op3 file is the database (the important one), the opc file
just creates a copy of the model you are solving - not so useful. The comi script currently also automatically solves the generated op3
file, but if not, you can manually start solving them by right clicking on the op3 file inside OPERA manager. When solving, solver.comi 
and monitor_shim_field.py will be automatically called to extract the field at the 27 sensor location. Two new files will be produced, a
.res file and a .txt file. The txt file will be formated B_at_points_000000.txt. By running the rename_results.py python script, it will
be automatically renamed to coilnum00.txt. 
5. To batch solve all 54 comi scripts, use the provided batch_solve.sh shell script. This needs some setup for a new PC. Takashi Higuchi 
is the person to talk to regarding this.