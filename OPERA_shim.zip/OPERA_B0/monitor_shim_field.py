# Python script integrated with Opera to monitor the field produced by shim coils at the sensor array location
# Jul 2024
# Author: M. Zhao

import operafea
import numpy as np
import time
#%%
t = time.strftime('%H%M%S')

# Global variables
# (x, y, z) position of sensor

sensor_xyz =    (np.float_((-0.25, -0.25, -0.25)),
                 np.float_((-0.25, -0.25,  0  )),
                 np.float_((-0.25, -0.25,  0.25)),
                 np.float_((-0.25,  0,   -0.25)),
                 np.float_((-0.25,  0,    0  )),
                 np.float_((-0.25,  0,    0.25)),
                 np.float_((-0.25,  0.25, -0.25)),
                 np.float_((-0.25,  0.25,  0  )),
                 np.float_((-0.25,  0.25,  0.25)),
                 np.float_(( 0,   -0.25, -0.25)),
                 np.float_(( 0,   -0.25,  0  )),
                 np.float_(( 0,   -0.25,  0.25)), 
                 np.float_(( 0,    0,   -0.25)),
                 np.float_((0, 0, 0)),
                 np.float_((0,   0,   0.25)),
                 np.float_(( 0,    0.25, -0.25)),
                 np.float_((0,   0.25, 0  )),   
                 np.float_((0,   0.25, 0.25)),
                 np.float_(( 0.25, -0.25, -0.25)),
                 np.float_(( 0.25, -0.25,  0  )),
                 np.float_(( 0.25, -0.25,  0.25)),
                 np.float_(( 0.25,  0,   -0.25)),
                 np.float_((0.25, 0,   0.  )),
                 np.float_((0.25, 0,   0.25)),
                 np.float_(( 0.25,  0.25, -0.25)),
                 np.float_((0.25, 0.25, 0  )),
                 np.float_((0.25, 0.25, 0.25)))

outputfile = "results//B_at_points_{}.txt".format(t)
print_header = True

def monitor_shim_field():
    # Module/file scope variables must be declared global if changed
    global print_header
    
    operafea.output("\n --------- Data extraction at end of solve ---------\n")
    
    simu = operafea.currentSimulation()  # Get the currently active simulation
    # Set flag allowing field output in every time step
    simu.addFlag('COMPUTEDATAPERTIMESTEP', True)
    
    # Iterate through all sensor locations, record B at location
    for xyz in sensor_xyz:
        # Use getFieldsAtCoords to get an opera object containing field info
        elem_ids = np.float_([])  # See documentation
        fields_info = simu.getFieldsAtCoords("RBX, RBY, RBZ", xyz, elem_ids)
    
        # Must extract each field component from fields_info
        bx = fields_info.getValue("RBX")[0]
        by = fields_info.getValue("RBY")[0]
        bz = fields_info.getValue("RBZ")[0]
        b_vec = np.array([bx, by, bz])  # field at point
    
        # Calculate modulus
        b_mod = np.sqrt(bx*bx + by*by + bz*bz)
    
        # Report to res file
        operafea.output("Field of interest: B (Tesla)\n")
        operafea.output("Coordinate (m): ({:1.3g}, {:1.3g}, {:1.3g})\n".format(*xyz))
        operafea.output("Field components (Tesla): ({:1.3g}, {:1.3g}, {:1.3g})\n".format(*b_vec))
        operafea.output("Field modulus (Tesla): {:1.3g}\n".format(b_mod))
        operafea.output(" ")
        # Write results to a file
        if print_header:  # on first call only
            print_header = False
            with open(outputfile, 'w') as f:
                # Delete old file and write header
                header_labels = ["x_(m)",
                                 "y_(m)",
                                 "z_(m)",
                                 "Bx_(T)",
                                 "By_(T)",
                                 "Bz_(T)",
                                 "Bmod_(T)"]
                line = ('{:>13s} ' * 7).format(*header_labels)
                f.write(line + '\n')
    
        with open(outputfile, 'a+') as f:
            # Write time, position and field values in columns
            line = ('{:13.3E} ' * 7).format(xyz[0], xyz[1], xyz[2], bx, by, bz, b_mod)
            f.write(line + '\n')
    
        operafea.output(" ---- Data extraction at end of solve (complete), saved at {} ----\n".format(outputfile))

























