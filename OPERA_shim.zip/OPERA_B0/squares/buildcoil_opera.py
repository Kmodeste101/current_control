#!/usr/bin/env python3

# Fri May 24 10:11:45 CDT 2019 Jeff added this line.

# Tue Feb 11 13:43:43 CST 2020 Jeff taking original patch.py and
# updating to solve the zero mode issue.  Will now update to use the
# patchlib submodule.

# Fri Feb 14 11:45:17 CST 2020 Jeff speeding up code by improving the
# sensorarray class to use numpy structures.

# Sat Aug 1 12:40:53 CDT 2020 Jeff added command line options and
# improved graphs

#Fri July 19 2024, Modeste added the opting to draw the msr and coroplast set up at line 1056 run with options -p.


from scipy.constants import mu_0, pi
import numpy as np
from patchlib.patch import *
from Pis.Pislib import *
from dipole import *

from pipesfitting import *

from optparse import OptionParser

#%%
parser = OptionParser()

parser.add_option("-s", "--nsensors", dest="nsensors", default=3,
                  help="ns where total sensor axes is s = 3*ns^3")

parser.add_option("-l", "--ell", dest="l", default=2,
                  help="l for spherical harmonic")

parser.add_option("-m", "--em", dest="m", default=0,
                  help="m for spherical harmonic")

parser.add_option("-M", "--matrices", dest="matrices", default=False,
                  action="store_true",
                  help="show matrices")

parser.add_option("-d", "--dipole", dest="dipole", default=False,
                  action="store_true",
                  help="use dipole field")

parser.add_option("-t", "--traces", dest="traces", default=False,
                  action="store_true",
                  help="show 3D view of coils and sensors")

parser.add_option("-r", "--residuals", dest="residuals", default=False,
                  action="store_true",
                  help="show residuals")

parser.add_option("-z", "--zoom", dest="zoom", default=False,
                  action="store_true",
                  help="zoom to ROI")

parser.add_option("-a", "--axes", dest="axes", default=False,
                  action="store_true",
                  help="make graphs along axes")

parser.add_option("-i", "--incells", dest="incells", default=False,
                  action="store_true",
                  help="ROI for statistics is in EDM cells")
parser.add_option("-p", "--makeplots", dest="makeplots", default=False,
                  action="store_true",
                  help="Make plots of walls")

#d=dipole(1.2,0,0,0,0,100000)  # dipole1
d=dipole(0,0,1.2,0,0,1)  # dipole2
#d=dipole(0,0,1.2,1,0,0)  # dipole3

(options,args)=parser.parse_args()

l=int(options.l)
m=int(options.m)
sp=scalarpotential(l,m)
print("Sigma in spherical coordinates is %s"%sp.Sigma_spherical)
print("Sigma in cartesian coordinates is %s"%sp.Sigma)

print("Pix is %s"%sp.Pix)
print("Piy is %s"%sp.Piy)
print("Piz is %s"%sp.Piz)

if(options.dipole):
    bxtarget=d.bx
    bytarget=d.by
    bztarget=d.bz
else:
    bxtarget=sp.fPix
    bytarget=sp.fPiy
    bztarget=sp.fPiz

# Setup our coilset

myset=coilset()

# positions of faces (positive values -- faces will be at plus and
# minus of these)
a=2.2 # approximate position of layer 6 of MSR
xface=a/2 # m
yface=a/2 # m
zface=a/2 # m

#picture frame separated by 40mm

# set up the rear wall   (East/west walls)
y1=300*.001
z1=300*.001
x1=xface
point1=(x1,y1,z1)
y2=y1
z2=600*0.001  # Jeff changed to fit on 4' sheet
x2=xface
point2=(x2,y2,z2)
y3=600*.001 # guess
z3=z2
x3=xface
point3=(x3,y3,z3)
y4=y3
z4=z1
x4=xface
point4=(x4,y4,z4)
points_ur=(point1,point2,point3,point4)
points_ur=np.array(points_ur)
myset.add_coil(points_ur)

# Now add mirror images of these
point1=(x1,-y1,z1)
point2=(x4,-y4,z4)
point3=(x3,-y3,z3)
point4=(x2,-y2,z2)
points_ul=(point1,point2,point3,point4)
points_ul=np.array(points_ul)
myset.add_coil(points_ul)

point1=(x1,-y1,-z1)
point2=(x2,-y2,-z2)
point3=(x3,-y3,-z3)
point4=(x4,-y4,-z4)
points_ll=(point1,point2,point3,point4)
points_ll=np.array(points_ll)
myset.add_coil(points_ll)

point1=(x1,y1,-z1)
point2=(x4,y4,-z4)
point3=(x3,y3,-z3)
point4=(x2,y2,-z2)
points_lr=(point1,point2,point3,point4)
points_lr=np.array(points_lr)
myset.add_coil(points_lr)

# now the central coil
x1=xface
y1=(235+5+20)*.001
z1=(157+5+98)*.001
point1=(x1,y1,z1)
point2=(x1,y1,-z1)
point3=(x1,-y1,-z1)
point4=(x1,-y1,z1)
points_c=(point1,point2,point3,point4)
points_c=np.array(points_c)
myset.add_coil(points_c)

# now the right side coil
x1=xface
y1=(235+5+20+40)*0.001
z1=(300-40)*.001
point1=(x1,y1,z1)
x2=xface
y2=600*.001 # guess
z2=z1
point2=(x2,y2,z2)
x3=xface
y3=y2
z3=-z2
point3=(x3,y3,z3)
x4=xface
y4=y1
z4=-z1
point4=(x4,y4,z4)
points_mr=(point1,point2,point3,point4)
print('points_mr',points_mr)
points_mr=np.array(points_mr)
myset.add_coil(points_mr)

# now the left side coil -- reflect and wind in same direction
point1=(x1,-y1,z1)
point2=(x4,-y4,z4)
point3=(x3,-y3,z3)
point4=(x2,-y2,z2)
points_ml=(point1,point2,point3,point4)
points_ml=np.array(points_ml)
myset.add_coil(points_ml)

# now the upper central coil
x1=xface
y1=(235+5+20)*0.001
z1=(300)*.001
point1=(x1,y1,z1)
x2=xface
y2=-y1 # guess
z2=z1
point2=(x2,y2,z2)
x3=xface
y3=y2
z3=600*.001
point3=(x3,y3,z3)
x4=xface
y4=y1
z4=z3
point4=(x4,y4,z4)
points_uc=(point1,point2,point3,point4)
print('points_uc',points_uc)
points_uc=np.array(points_uc)
myset.add_coil(points_uc)

# now the lower central coil -- reflect and wind in same direction
point1=(x1,y1,-z1)
point2=(x4,y4,-z4)
point3=(x3,y3,-z3)
point4=(x2,y2,-z2)
points_lc=(point1,point2,point3,point4)
points_lc=np.array(points_lc)
myset.add_coil(points_lc)

# now reflect them all to the other face: xface -> -xface
def reflect_x(points):
    newpoints=np.copy(points)
    newpoints[:,0]=-newpoints[:,0]
    newpoints=np.flip(newpoints,0) # wind them in the opposite direction
    return newpoints
    
oside_ur=reflect_x(points_ur)
myset.add_coil(oside_ur)
oside_ul=reflect_x(points_ul)
myset.add_coil(oside_ul)
oside_ll=reflect_x(points_ll)
myset.add_coil(oside_ll)
oside_lr=reflect_x(points_lr)
myset.add_coil(oside_lr)
oside_c=reflect_x(points_c)
myset.add_coil(oside_c)
oside_ml=reflect_x(points_ml)
myset.add_coil(oside_ml)
oside_mr=reflect_x(points_mr)
myset.add_coil(oside_mr)
oside_uc=reflect_x(points_uc)
myset.add_coil(oside_uc)
oside_lc=reflect_x(points_lc)
myset.add_coil(oside_lc)

# Phew -- now onto the sides  (North/southwalls)
    
z1=(260-5-40)*.001
x1=(220-5)*.001
y1=-yface
point1=(x1,y1,z1)
z2=600*.001 #guess
x2=x1
y2=-yface
point2=(x2,y2,z2)
z3=z2
x3=600*.001 #guess
y3=-yface
point3=(x3,y3,z3)
z4=z1
x4=x3
y4=-yface
point4=(x4,y4,z4)
side_ur=(point1,point2,point3,point4)
side_ur=np.array(side_ur)
myset.add_coil(side_ur)

# now reflect around
point1=(-x1,y1,z1)
point2=(-x4,y4,z4)
point3=(-x3,y3,z3)
point4=(-x2,y2,z2)
side_ul=np.array((point1,point2,point3,point4))
myset.add_coil(side_ul)

point1=(-x1,y1,-z1)
point2=(-x2,y2,-z2)
point3=(-x3,y3,-z3)
point4=(-x4,y4,-z4)
side_ll=np.array((point1,point2,point3,point4))
myset.add_coil(side_ll)

point1=(x1,y1,-z1)
point2=(x4,y4,-z4)
point3=(x3,y3,-z3)
point4=(x2,y2,-z2)
side_lr=np.array((point1,point2,point3,point4))
myset.add_coil(side_lr)

# central coil
z1=(170+5)*.001
y1=-yface
x1=(-221-5)*.001
point1=(x1,y1,z1)
point2=(x1,y1,-z1)
point3=(-x1,y1,-z1)
point4=(-x1,y1,z1)
side_c=np.array((point1,point2,point3,point4))
myset.add_coil(side_c)

# middle right coil
x1=(221+5+40)*.001
y1=-yface
z1=(170+5)*.001
point1=(x1,y1,z1)
x2=600*.001 #guess
y2=-yface
z2=z1
point2=(x2,y2,z2)
point3=(x2,y2,-z2)
point4=(x1,y1,-z1)
side_mr=np.array((point1,point2,point3,point4))
myset.add_coil(side_mr)

# reflect it to middle left coil
point1=(-x1,y1,z1)
point2=(-x1,y1,-z1)
point3=(-x2,y2,-z2)
point4=(-x2,y2,z2)
side_ml=np.array((point1,point2,point3,point4))
myset.add_coil(side_ml)

# middle top
z1=600*.001
x1=(220-5-40)*.001
y1=-yface
point1=(x1,y1,z1)
z2=z1
x2=-x1
y2=-yface
point2=(x2,y2,z2)
z3=(260-5-40)*.001
x3=x2
y3=-yface 
point3=(x3,y3,z3)
z4=z3
x4=x1
y4=-yface
point4=(x4,y4,z4)
side_mt=np.array((point1,point2,point3,point4))
myset.add_coil(side_mt)

# mirror to middle bottom
point1=(x1,y1,-z1)
point2=(x4,y4,-z4)
point3=(x3,y3,-z3)
point4=(x2,y2,-z2)
side_mb=np.array((point1,point2,point3,point4))
myset.add_coil(side_mb)

# now reflect them all to the other face: -yface -> yface
def reflect_y(points):
    newpoints=np.copy(points)
    newpoints[:,1]=-newpoints[:,1]
    newpoints=np.flip(newpoints,0) # wind them in the opposite direction
    return newpoints

oside_side_ur=reflect_y(side_ur)
oside_side_ul=reflect_y(side_ul)
oside_side_ll=reflect_y(side_ll)
oside_side_lr=reflect_y(side_lr)
oside_side_c=reflect_y(side_c)
oside_side_ml=reflect_y(side_ml)
oside_side_mr=reflect_y(side_mr)
oside_side_mt=reflect_y(side_mt)
oside_side_mb=reflect_y(side_mb)

myset.add_coil(oside_side_ur)
myset.add_coil(oside_side_ul)
myset.add_coil(oside_side_lr)
myset.add_coil(oside_side_ll)
myset.add_coil(oside_side_c)
myset.add_coil(oside_side_ml)
myset.add_coil(oside_side_mr)
myset.add_coil(oside_side_mt)
myset.add_coil(oside_side_mb)


# Double phew, now on to the top side  (Floor and ceiling)

x1=(300)*.001
y1=600*.001
z1=zface
point1=(x1,y1,z1)
x2=600*.001
y2=y1
z2=zface
point2=(x2,y2,z2)
x3=x2
y3=x1
z3=zface
point3=(x3,y3,z3)
x4=x1
y4=y3
z4=zface
point4=(x4,y4,z4)
top_ur=(point1,point2,point3,point4)
top_ur=np.array(top_ur)
myset.add_coil(top_ur)

# now reflect around
point1=(-x1,y1,z1)
point2=(-x4,y4,z4)
point3=(-x3,y3,z3)
point4=(-x2,y2,z2)
top_ul=np.array((point1,point2,point3,point4))
myset.add_coil(top_ul)

point1=(-x1,-y1,z1)
point2=(-x2,-y2,z2)
point3=(-x3,-y3,z3)
point4=(-x4,-y4,z4)
top_ll=np.array((point1,point2,point3,point4))
myset.add_coil(top_ll)

point1=(x1,-y1,z1)
point2=(x4,-y4,z4)
point3=(x3,-y3,z3)
point4=(x2,-y2,z2)
top_lr=np.array((point1,point2,point3,point4))
myset.add_coil(top_lr)

# central coil
z1=zface
y1=(245+5+10)*.001
x1=(245+5+10)*.001
point1=(x1,y1,z1)
point2=(x1,-y1,z1)
point3=(-x1,-y1,z1)
point4=(-x1,y1,z1)
top_c=np.array((point1,point2,point3,point4))
myset.add_coil(top_c)

# middle right coil
x1=300*.001
y1=(245+5+10)*.001
z1=zface
point1=(x1,y1,z1)
x2=600*.001
y2=y1
z2=zface
point2=(x2,y2,z2)
point3=(x2,-y2,z2)
point4=(x1,-y1,z1)
top_mr=np.array((point1,point2,point3,point4))
myset.add_coil(top_mr)

# reflect it to middle left coil
point1=(-x1,y1,z1)
point2=(-x1,-y1,z1)
point3=(-x2,-y2,z2)
point4=(-x2,y2,z2)
top_ml=np.array((point1,point2,point3,point4))
myset.add_coil(top_ml)

# middle top
x1=(300-40)*.001
y1=600*.001
z1=zface
point1=(x1,y1,z1)
x2=-x1
y2=y1
z2=zface
point2=(x2,y2,z2)
x3=x2
y3=(245+5+10+40)*.001
z3=zface
point3=(x3,y3,z3)
x4=x1
y4=y3
z4=zface
point4=(x4,y4,z4)
top_mt=np.array((point1,point2,point3,point4))
myset.add_coil(top_mt)

# mirror to middle bottom
point1=(x1,-y1,z1)
point2=(x4,-y4,z4)
point3=(x3,-y3,z3)
point4=(x2,-y2,z2)
top_mb=np.array((point1,point2,point3,point4))
myset.add_coil(top_mb)

# now reflect them all to the other face: zface -> -zface
def reflect_z(points):
    newpoints=np.copy(points)
    newpoints[:,2]=-newpoints[:,2]
    newpoints=np.flip(newpoints,0) # wind them in the opposite direction
    return newpoints

bott_ur=reflect_z(top_ur)
bott_ul=reflect_z(top_ul)
bott_ll=reflect_z(top_ll)
bott_lr=reflect_z(top_lr)
bott_c=reflect_z(top_c)
bott_ml=reflect_z(top_ml)
bott_mr=reflect_z(top_mr)
bott_mt=reflect_z(top_mt)
bott_mb=reflect_z(top_mb)

myset.add_coil(bott_ur)
myset.add_coil(bott_ul)
myset.add_coil(bott_lr)
myset.add_coil(bott_ll)
myset.add_coil(bott_c)
myset.add_coil(bott_ml)
myset.add_coil(bott_mr)
myset.add_coil(bott_mt)
myset.add_coil(bott_mb)

class sensor:
    def __init__(self,pos):
        self.pos = pos

class sensorarray:
    def __init__(self,xdim,ydim,zdim,corners):
        x = corners[1]-corners[0]
        y = corners[2]-corners[0]
        z = corners[3]-corners[0]
        #self.sensorgrid=np.mgrid[-a:a:xdim*1j,-a:a:ydim*1j,-a:a:zdim*1j]
        #print(self.sensorgrid)
        self.sensors = []
        if(xdim==1 and ydim==1 and zdim==1):
            pos = corners[0]+x/2+y/2
            self.sensors.append(sensor(pos))
            pos = corners[0]+x/2+y/2+z
            self.sensors.append(sensor(pos))
            pos = corners[0]+y/2+z/2
            self.sensors.append(sensor(pos))
            pos = corners[0]+y/2+z/2+x
            self.sensors.append(sensor(pos))
            pos = corners[0]+x/2+z/2
            self.sensors.append(sensor(pos))
            pos = corners[0]+x/2+z/2+y
            self.sensors.append(sensor(pos))
        else:
            for i in range(xdim):
                for j in range(ydim):
                    for k in range(zdim):
                        pos = corners[0]+x*i/(xdim-1)+y*j/(ydim-1)+z*k/(zdim-1)
                        self.sensors.append(sensor(pos))
        self.numsensors = len(self.sensors)
    def draw_sensor(self,number,ax):
        x = self.sensors[number].pos[0]
        y = self.sensors[number].pos[1]
        z = self.sensors[number].pos[2]
        c = 'r'
        m = 'o'
        ax.scatter(x,y,z,c=c,marker=m)
    def draw_sensors(self,ax):
        for number in range(self.numsensors):
            self.draw_sensor(number,ax)
    def vec_b(self):
        # makes a vector of magnetic fields in the same ordering as
        # the_matrix class below
        the_vector=np.zeros((self.numsensors*3))
        for j in range(myarray.numsensors):
            r = myarray.sensors[j].pos
            b=np.array([bxtarget(r[0],r[1],r[2]),
                        bytarget(r[0],r[1],r[2]),
                        bztarget(r[0],r[1],r[2])])
            for k in range(3):
                the_vector[j*3+k]=b[k]
        return the_vector


# set up array of sensors
a_sensors=0.5
p0=np.array([-a_sensors/2,-a_sensors/2,-a_sensors/2])
p1=p0+np.array([a_sensors,0,0])
p2=p0+np.array([0,a_sensors,0])
p3=p0+np.array([0,0,a_sensors])
points=(p0,p1,p2,p3)

nsensors=int(options.nsensors)
myarray=sensorarray(nsensors,nsensors,nsensors,points)




#%% BELOW IS MZ ADDITION 
fig = plt.figure(figsize=(6,6))
ax=fig.add_subplot(111,projection='3d')

for number in range(54):
    coil = myset.coil[number]
    points = coil.points
    myset.draw_coil(number, ax, style='-',color='black')
    # myarray.draw_sensor(number, ax)
    # print('coil number {} has points {}'.format(number, points))

ax.set_xlabel('x (m)')
ax.set_ylabel('y (m)')
ax.set_zlabel('z (m)')

#%% Generate OPERA script with a single coil
''' basic template in opera for making a rectangular coil
RACETRACK OPTION=LOAD
RACETRACK OPTION=NEW -KEEP XP1=1 YP1=1 WIDTH=0.1 THICKNESS=0.1 H1=0.5 R1=0.1 INCIRCUIT=NO CIRCUITELEMENT= CURD=1 
          TOLERANCE=0 DRIVELABEL='coil1' THETA2=0 PHI2=0 PSI2=0 XCEN2=0 YCEN2=0 ZCEN2=0 LCNAME='Global coordinate system' 
          RXY=0 RYZ=0 RZX=0 SYMMETRY=1 MODELCOMPONENT=NO
          
          use the Opera modeller -> racetrack conductor tab to understand what each setting does
'''

for i in range(54):
    # coil number to generate. Either integer from 0 to 53,
    coil_to_create = i
    
    
    ### settings 
    save_file_path = "..//comi//make_coil{}.comi".format(coil_to_create)
    # wire side length [m] (conductors in opera have square profiles)
    wire_sl = 0.001 
    # wire corner radius [m]
    wire_cr = 0.001
    # mumetal relative permeability 
    rel_mu = 2e4
    # current (A) 
    cur = 1
    
    
    # empty existing comi file
    open(save_file_path, 'w').close()
    
    # add preamble
    with open(save_file_path, "a") as text_file:
        text_file.write("$string yesorno YES"+"\n"+
                        "CLEAR REVERT=NO"+"\n"+
                        "THREED XORIGIN=0 YORIGIN=0 ZORIGIN=0 ROTX=0 ROTY=0 ROTZ=0 XASPECT=1 YASPECT=1 ZASPECT=1 SIZE=0 FACETANGLE=5 PERSPECTIVE=YES LINECOLOUR=YES OPTION=SETVIEW"
                        +"\n"+"\n")
    
    # define constants
    with open(save_file_path, "a") as text_file:
        text_file.write('\n'.join(["//Data Storage Levels",
                        "VARIABLE OPTION=PARAMETER, NAME=#mu_DSL, Value=1000, DESCRIPTION='data storage level for mumetal'",
                        "VARIABLE OPTION=PARAMETER, NAME=#air_tot_DSL, Value=600, DESCRIPTION='data storage level for total potential air'",
                        "VARIABLE OPTION=PARAMETER, NAME=#air_red_DSL, Value=50, DESCRIPTION='data storage level for reduced potential air'",
                        "/// meshing parameters",
                        "// max element size (MES)",
                        "VARIABLE OPTION=PARAMETER, NAME=#mu_flat_MES, Value=0.03, DESCRIPTION='maximum element size for flat mumetal'",
                        "VARIABLE OPTION=PARAMETER, NAME=#air_tot_MES, Value=0.1, DESCRIPTION='maximum element size for total potential air'",
                        "VARIABLE OPTION=PARAMETER, NAME=#air_red_MES, Value=0.1, DESCRIPTION='maximum element size for reduced potential air'",
                        "// maximum angle between elements (MAbE)",
                        "VARIABLE OPTION=PARAMETER, NAME=#mu_flat_MAbE, Value=30, DESCRIPTION='maximum angle between elements for flat mumetal'",
                        "VARIABLE OPTION=PARAMETER, NAME=#air_grad_MAbE, Value=30, DESCRIPTION='maximum angle between elements for air'"])+"\n"+"\n")
    
    
    
    
    # Generate Coil
    if 0 <= coil_to_create < 18:
        # Build coil on x = +/-1.1 m
        with open(save_file_path, "a") as text_file:
            text_file.write("// Coils on x = +/-1.1m"+"\n"+"\n")
         
        number = coil_to_create
        coil = myset.coil[number]
        points = coil.points
        
       
        # calculate origin of coil
        coil_origin = np.round(np.asarray([np.mean(points[:, 0]), np.mean(points[:, 1]), np.mean(points[:, 2])]), 4)
        # calculate relevant geometry constants for opera
        xp = np.around(np.abs(np.abs(np.max(points[:, 2]))-np.abs(coil_origin[2])), 4)
        h1 = np.around(np.abs(np.abs(np.max(points[:, 1]))-np.abs(coil_origin[1])), 4)
        # euler angle in order of theta, phi, psi, to rotate coil into proper orientation
        euler_angles = np.asarray([90, 90, 180])
        # current density 
        cur_mag = cur / wire_sl**2
        with open(save_file_path, "a") as text_file:
            text_file.write("RACETRACK OPTION=LOAD"+"\n"+
                            "RACETRACK OPTION=NEW -KEEP XP1={XP1} YP1={YP1} WIDTH={width} THICKNESS={thick} H1={h1} R1={radius} INCIRCUIT=NO CIRCUITELEMENT= CURD={CD} TOLERANCE=0 DRIVELABEL='coil{label}' THETA2={EA0} PHI2={EA1} PSI2={EA2} XCEN2={Ox} YCEN2={Oy} ZCEN2={Oz} LCNAME='Global coordinate system' RXY=0 RYZ=0 RZX=0 SYMMETRY=1 MODELCOMPONENT=NO".format(
                                XP1=xp, YP1=-wire_sl/2,
                                width=wire_sl, thick=wire_sl, 
                                h1=h1, radius=wire_cr,
                                CD=cur_mag,
                                label=number,
                                EA0=euler_angles[0], EA1=euler_angles[1], EA2=euler_angles[2],
                                Ox=coil_origin[0], Oy=coil_origin[1], Oz=coil_origin[2])
                            +"\n"+"\n")
                
    elif 18 <= coil_to_create < 36:
        # Build coil on y = +/-1.1 m
        with open(save_file_path, "a") as text_file:
            text_file.write("// Coils on y = +/-1.1m"+"\n"+"\n")
            
        number = coil_to_create
        coil = myset.coil[number]
        points = coil.points
        
       
        # calculate origin of coil
        coil_origin = np.round(np.asarray([np.mean(points[:, 0]), np.mean(points[:, 1]), np.mean(points[:, 2])]), 4)
        # calculate relevant geometry constants for opera
        h1 = np.around(np.abs(np.abs(np.max(points[:, 2]))-np.abs(coil_origin[2])), 4)
        xp = np.around(np.abs(np.abs(np.max(points[:, 0]))-np.abs(coil_origin[0])), 4)
        # euler angle in order of theta, phi, psi, to rotate coil into proper orientation
        euler_angles = np.asarray([0, 0, 0])
        # current density 
        cur_mag = cur / wire_sl**2
        with open(save_file_path, "a") as text_file:
            text_file.write("RACETRACK OPTION=LOAD"+"\n"+
                            "RACETRACK OPTION=NEW -KEEP XP1={XP1} YP1={YP1} WIDTH={width} THICKNESS={thick} H1={h1} R1={radius} INCIRCUIT=NO CIRCUITELEMENT= CURD={CD} TOLERANCE=0 DRIVELABEL='coil{label}' THETA2={EA0} PHI2={EA1} PSI2={EA2} XCEN2={Ox} YCEN2={Oy} ZCEN2={Oz} LCNAME='Global coordinate system' RXY=0 RYZ=0 RZX=0 SYMMETRY=1 MODELCOMPONENT=NO".format(
                                XP1=xp, YP1=-wire_sl/2,
                                width=wire_sl, thick=wire_sl, 
                                h1=h1, radius=wire_cr,
                                CD=cur_mag,
                                label=number,
                                EA0=euler_angles[0], EA1=euler_angles[1], EA2=euler_angles[2],
                                Ox=coil_origin[0], Oy=coil_origin[1], Oz=coil_origin[2])
                                +"\n"+"\n")
            
    elif 36 <= coil_to_create < 54:
        # Build coil on z = +/-1.1 m
        with open(save_file_path, "a") as text_file:
            text_file.write("// Coils on z = +/-1.1m"+"\n"+"\n")
            
        number = coil_to_create
        coil = myset.coil[number]
        points = coil.points
        
       
        # calculate origin of coil
        coil_origin = np.round(np.asarray([np.mean(points[:, 0]), np.mean(points[:, 1]), np.mean(points[:, 2])]), 4)
        # calculate relevant geometry constants for opera
        xp = np.around(np.abs(np.abs(np.max(points[:, 1]))-np.abs(coil_origin[1])), 4)
        h1 = np.around(np.abs(np.abs(np.max(points[:, 0]))-np.abs(coil_origin[0])), 4)
        # euler angle in order of theta, phi, psi, to rotate coil into proper orientation
        euler_angles = np.asarray([90, 0, 90])
        # current density 
        cur_mag = cur / wire_sl**2
        with open(save_file_path, "a") as text_file:
            text_file.write("RACETRACK OPTION=LOAD"+"\n"+
                            "RACETRACK OPTION=NEW -KEEP XP1={XP1} YP1={YP1} WIDTH={width} THICKNESS={thick} H1={h1} R1={radius} INCIRCUIT=NO CIRCUITELEMENT= CURD={CD} TOLERANCE=0 DRIVELABEL='coil{label}' THETA2={EA0} PHI2={EA1} PSI2={EA2} XCEN2={Ox} YCEN2={Oy} ZCEN2={Oz} LCNAME='Global coordinate system' RXY=0 RYZ=0 RZX=0 SYMMETRY=1 MODELCOMPONENT=NO".format(
                                XP1=xp, YP1=-wire_sl/2,
                                width=wire_sl, thick=wire_sl, 
                                h1=h1, radius=wire_cr,
                                CD=cur_mag,
                                label=number,
                                EA0=euler_angles[0], EA1=euler_angles[1], EA2=euler_angles[2],
                                Ox=coil_origin[0], Oy=coil_origin[1], Oz=coil_origin[2])
                            +"\n"+"\n")
    
    
    # Put in layer 6 magnetic shielding
    with open(save_file_path, "a") as text_file:
        text_file.write('\n'.join(["LOAD OPTION=INSERT FILE='stpfiles//layer6_floor.STEP'",
                                   "/ rename",
                                   "FILTER TYPE=BODY",
                                   "PREVIEW OPTION=PICK | PICK OPTION=ADD PROPERTY=UniqueName LABEL='Unnamed:AAA-001'",
                                   "PREVIEW OPTION=ACCEPT REDISPLAY=NO |  RENAME NAME='l6_floor' UNIQUENAME='l6_floor'",
                                   "/ set material to mumetal",
                                   "PREVIEW OPTION=PICK | PICK OPTION=ADD PROPERTY=UniqueName LABEL='l6_floor'",
                                   "PREVIEW OPTION=ACCEPT REDISPLAY=NO |  CELLDATA OPTION=MODIFY MATERIALLABEL='layer6' ELEMENTTYPE=Linear LEVEL=#mu_DSL SIZE=#mu_flat_MES NORMALTOL=#mu_flat_MAbE ELEMSHAPEPREF=NONE",
                                   "LOAD OPTION=INSERT FILE='stpfiles//layer6_door.STEP'",
                                   "/ rename",
                                   "FILTER TYPE=BODY",
                                   "PREVIEW OPTION=PICK | PICK OPTION=ADD PROPERTY=UniqueName LABEL='Unnamed:AAB-001'",
                                   "PREVIEW OPTION=ACCEPT REDISPLAY=NO |  RENAME NAME='l6_door' UNIQUENAME='l6_door'",
                                   "/ set material to mumetal",
                                   "PREVIEW OPTION=PICK | PICK OPTION=ADD PROPERTY=UniqueName LABEL='l6_door'",
                                   "PREVIEW OPTION=ACCEPT REDISPLAY=NO |  CELLDATA OPTION=MODIFY MATERIALLABEL='layer6' ELEMENTTYPE=Linear LEVEL=#mu_DSL SIZE=#mu_flat_MES NORMALTOL=#mu_flat_MAbE ELEMSHAPEPREF=NONE",
                                   "LOAD OPTION=INSERT FILE='stpfiles//layer6_body.STEP'",
                                   "/ rename",
                                   "FILTER TYPE=BODY",
                                   "PREVIEW OPTION=PICK | PICK OPTION=ADD PROPERTY=UniqueName LABEL='Unnamed:AAC-001'",
                                   "PREVIEW OPTION=ACCEPT REDISPLAY=NO |  RENAME NAME='l6_body' UNIQUENAME='l6_body'",
                                   "/ set material to mumetal",
                                   "PREVIEW OPTION=PICK | PICK OPTION=ADD PROPERTY=UniqueName LABEL='l6_body'",
                                   "PREVIEW OPTION=ACCEPT REDISPLAY=NO |  CELLDATA OPTION=MODIFY MATERIALLABEL='layer6' ELEMENTTYPE=Linear LEVEL=#mu_DSL SIZE=#mu_flat_MES NORMALTOL=#mu_flat_MAbE ELEMSHAPEPREF=NONE"])+"\n"+"\n")
    # Air regions
    with open(save_file_path, "a") as text_file:
        text_file.write('\n'.join(["// Total air (central region)",
                                   "SKETCH OBJECT=BLOCK +COMPLETE",
                                   "BLOCK Name='air_internal' X0=1 Y0=1 Z0=1 X1=-1 Y1=-1 Z1=-1 MATERIALLABEL='Air' LEVEL=#air_tot_DSL",
                                   "/ mesh parameters",
                                   "PREVIEW OPTION=PICK | PICK OPTION=ADD PROPERTY=UniqueName LABEL='air_internal' ",
                                   "PREVIEW OPTION=ACCEPT REDISPLAY=NO |  CELLDATA OPTION=MODIFY MATERIALLABEL='Air' POTENTIAL=Total ELEMENTTYPE=Linear SIZE=#air_tot_MES NORMALTOL=#air_grad_MAbE ELEMSHAPEPREF=NONE",
                                   "// Reduced air (Coil/Shield/External Region)",
                                   "SKETCH OBJECT=BLOCK +COMPLETE",
                                   "BLOCK Name='air_external' X0=1.4 Y0=1.4 Z0=1.4 X1=-1.4 Y1=-1.4 Z1=-1.4 MATERIALLABEL='Air' LEVEL=#air_red_DSL",
                                   "/ mesh parameters",
                                   "PREVIEW OPTION=PICK | PICK OPTION=ADD PROPERTY=UniqueName LABEL='air_external' ",
                                   "PREVIEW OPTION=ACCEPT REDISPLAY=NO |  CELLDATA OPTION=MODIFY MATERIALLABEL='Air' POTENTIAL=Reduced ELEMENTTYPE=Linear SIZE=#air_red_MES NORMALTOL=#air_grad_MAbE ELEMSHAPEPREF=NONE"])+"\n"+"\n")
    
    # BH
    with open(save_file_path, "a") as text_file:
        text_file.write('\n'.join(["//// BH ",
                                   "MATERIALS UNPICK | MATERIALS GUIINIT",
                                   "MATERIALS PICK 'layer6'",
                                   "MATERIALS MATERIALS OPTION=MODIFY MULINEARITY=LINEAR MUANISOTROPY=ISOTROPIC MU={} HC=0.0 | MATERIALS UNPICK".format(rel_mu)])+"\n"+"\n")
    
    # Symmetry
    with open(save_file_path, "a") as text_file:
        text_file.write('\n'.join(["//// Background",
                                   "BACKGROUND OPTION=LOAD",
                                   "BACKGROUND OPTION=SET SHAPE=BLOCK SCALEX=2 SCALEY=2 SCALEZ=2 XYSYMMETRYPLANE=NO YZSYMMETRYPLANE=NO ROTZNUM=1 ZXSYMMETRYPLANE=NO "])+"\n"+"\n")
    
    # Analysis Settings
    with open(save_file_path, "a") as text_file:
        text_file.write('\n'.join(["//// Analysis Settings",
                                   "MULTIPHYSICS OPTION=RESET",
                                   "ANALYSISDATA OPTION=SET PROGRAM=TOSCAMAGN HX=0 HY=0 HZ=0 LINEAR=YES NITERATIONS=21 NLITERTYPE=NEWTON POTENTIALCUT=YES RHS=ADAPTIVE SCALEDRIVE=ALL TOLERANCE=0.001 USEDEFORMEDMESH=NO USEDIRECTSOLVER=NO"])+"\n"+"\n")
    
    # Create Model Body and Mesh
    with open(save_file_path, "a") as text_file:
        text_file.write('\n'.join(["//// Create Model Body",
                                   "MODEL CREATE",
                                   "MESH GENERATOR=AUTOMATIC SIZE=0.5 NORMALTOL=30.0 SURFACETOL=0.0 TOLERANCE=1.0E-06 TYPE=PREFERTETRA ",
                                   "FILL TOL=1.0E-06"])+"\n"+"\n")
    
    def format_num(num):
        '''
        formats single digit number n into '0n', leave two digit number as is
        '''
        
        if len(str(num)) == 1:
            return '0'+str(num)
        elif len(str(num)) == 2:
            return str(num)
    
    
    # Solve
    with open(save_file_path, "a") as text_file:
        text_file.write('\n'.join(["//// Solve",
                                   "SOLVERS SOLVENOW=YES SAVEMODEL=YES, | SOLVERS OPTION=TEST FILE=coilnum{} UNITS=METRE ELEMENT=MIXED SURFACE=CURVED | COMMENT CLEAR=YES TYPE=DBTITLE | SOLVERS OPTION=OVERWRITE".format(format_num(coil_to_create)),
                                   "$string yesorno YES",
                                   "END"])+"\n"+"\n")
    
    





















