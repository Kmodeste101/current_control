# Anaalyze BH curves from MSR 
# may 2024

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os, glob
from scipy import integrate
import scipy
from scipy.optimize import curve_fit
from scipy.integrate import odeint
from scipy.interpolate import CubicSpline

def remove_offset(arr):
    return arr - np.mean(arr)

def linfunc(x, m, b):
    return m*x+b

def sinfunc(x, a):
    return a*np.sin(2*np.pi*1/200*x)

def H_denoise(H, mode, freq=1):
    if mode == 'sin':
        sin_p, sin_pcov = curve_fit(sinfunc, np.arange(len(H)), H)
        return sin_p[0]*np.sin(2*np.pi*freq/10000*np.arange(len(H)) - sin_p[1])
    elif mode == 'lin':
        lin_p, lin_pcov = curve_fit(linfunc, np.arange(len(H)), H)
        return lin_p[0]*np.arange(len(H)) + lin_p[1]

def sort_custom(arr, disc_idx):
    out = np.zeros_like(arr)
    out[-disc_idx:] = arr[:disc_idx]
    out[:len(arr)-disc_idx] = arr[disc_idx:]  
    return out

# define differential equation
def coth(x):
    return 1 / np.tanh(x)

def csch(x):
    return 1 / np.sinh(x)

def B_an(B_s, x):
    return B_s*(coth(x) - 1/x)

def dB_an(B_s, x):
    return B_s*(1/x**2 - 1/(np.tanh(x))**2 + 1)

def B_an(B_s, x):
    if isinstance (x, np.ndarray):
        t = np.copy(x)
        for n in range(len(x)):
            t[n] = B_an(B_s, t[n])
        return t

    if (abs (x) > 10 ** -4):
        return B_s*(coth(x) - (1/x))
    else:
        return B_s*(x/3)

def DIMFH_increase(B, H, B_s, a, b, h):
    dBdH = (B_s*(coth((H + b*B)/a) - a/(H + b*B)) - B)/(h)
    return dBdH

def DIMFH_decrease(B, H, B_s, a, b, h):
    dBdH = (B_s*(coth((H + b*B)/a) - a/(H + b*B)) - B)/(-1*h)
    return dBdH

def y_increase(t, M_s, a, b, h, y0):
    """
    Solution to the ODE y'(t) = f(t,y,a,b) with initial condition y(0) = y0
    """
    y = odeint(DIMFH_increase, y0, t, args=(M_s, a, b, h))
    return y.ravel()

def y_decrease(t, M_s, a, b, h, y0):
    """
    Solution to the ODE y'(t) = f(t,y,a,b) with initial condition y(0) = y0
    """
    y = odeint(DIMFH_decrease, y0, t, args=(M_s, a, b, h))
    return y.ravel()

def invert_sgn_V(V, I, sr):
    '''
    Inverts sign of induced voltage V, if necessary
    '''
    B_test = integrate.cumulative_trapezoid(V[10:10+sr], dx=1/sr)
    H_test = I[10:10+sr]
    
    # value of B at max H
    B_Hmax = B_test[np.argmax(H_test)]
    B_Hmin = B_test[np.argmin(H_test)]
    
    # compare
    if B_Hmax > B_Hmin:
        return V
    else:
        return -V
      
plt.rcParams.update({'font.size': 14})
#%% 
c_dict = {'L1x':'C0',
          'L1y':'C1',
          'L1z':'C2',
          'L2':'C3',
          'L3':'C4',
          'L5x':'C5',
          'L5y':'C6',
          'L5z':'C7'}

# fig, ax = plt.subplots(2, 4, figsize=(12, 6))

ct = 0
for filename in glob.glob('..//data//MSR//20240524//select//*.csv'):
    df = pd.read_csv(filename, comment='#')
    # sampling rate
    sr = 200
    
    # dictionary of layer thickness in m
    tkns_dict = {'1':0.004,
              '2':0.003,
              '3':0.003,
              '5':0.002}
    
    # dictionary of layer side length in m
    sl_dict = {'1':3.5,
               '2':3,
               '3':2.6,
               '5':2.4}
    
    # get layer number
    layer = str(int(os.path.basename(filename)[1]))
    
    # get orientation
    if layer in ('1', '5'):
        orientation = os.path.basename(filename)[2]
    else:
        orientation = ''
    
    I = np.asarray(df['Hantek (V)'])[sr:] / 0.01
    V = np.asarray(df['Pickup {} (V)'.format('L'+layer+orientation)])[sr:]
    
    V = invert_sgn_V(V, I, sr)
    
    I = remove_offset(I)[:sr+2]
    V = remove_offset(V)[:sr+2]
    
    tkns = tkns_dict[layer]
    sl = sl_dict[layer]
    
    # check edge coil status
    is_edge_coil = layer not in ('2', '3')
    
    # calculate flux length and cross sectional area based on edge coil status
    if is_edge_coil:
        fl = 4 * sl
        A = sl * tkns
    else: 
        fl = 2 * (1 + np.sqrt(2)) * sl
        A = 2 * sl * tkns
    

    
    # number of windings
    N_dri = 4*4
    N_ind = 1*4
    
    H = N_dri * I / fl
    H = H[:-1]
    B = 1 / (N_ind * A) * integrate.cumulative_trapezoid(V, dx=1/sr)
    B = remove_offset(B)
    M = B / scipy.constants.mu_0 - H
    
    # fig, axs = plt.subplots(1, 2, figsize=(1.5*6.4, 4.8))
    # # inset 
    # # x1, x2, y1, y2 = 0, 200, -0.9, 0.9  # subregion of the original image
    # # axins = axs[0].inset_axes(
    # #     [0.07, 0.05, 0.4, 0.4],
    # #     xlim=(x1, x2), ylim=(y1, y2))

    
    # axs[0].plot(V, label='Pickup V')
    # ax = axs[0].twinx()
    # ax.plot(I, label='Driving I', color='C1')
    
    # axs[1].plot(H, B)
    # axs[1].set_title('L'+layer+orientation)
    # axs[1].set_xlabel('H (A/m)')
    # axs[1].set_ylabel('B (T)')
    
    # axs[0].set_ylabel('Induced Voltage (V)', color='C0')
    # ax.set_ylabel('Driving Current (A)', color='C1')
    # axins.plot(V)
    
    # if ct<4:
    #     ax[0, ct].plot(H, B)
    #     ax[0, ct].set_title('L'+layer+orientation)
    #     ax[0, ct].set_xlabel('H (A/m)')
    #     ax[0, ct].set_ylabel('B (T)')
    #     ct += 1
    # else:
    #     ax[1, ct-4].plot(H, B)
    #     ax[1, ct-4].set_title('L'+layer+orientation)
    #     ax[1, ct-4].set_xlabel('H (A/m)')
    #     ax[1, ct-4].set_ylabel('B (T)')
    #     ct += 1
    # axins.set_yticklabels([])
    # axins.set_xticklabels([])
    # axs[0].indicate_inset_zoom(axins, edgecolor="black", linewidth=1)
    
    #plt.tight_layout()
    #plt.savefig('..//figures//MSR_BH//20240524//{}.pdf'.format('L'+layer+orientation))
    # # plt.show()
    sin_p, sin_pcov = curve_fit(sinfunc, np.arange(len(H)), H)
    H_fit = sinfunc(np.arange(len(H)), *sin_p)
    
    plt.plot(H_fit[50:149], np.divide(np.diff(B[50:150]), np.diff(H_fit[50:150]))/scipy.constants.mu_0, '*', label='L'+layer+orientation,
              color=c_dict['L'+layer+orientation])
plt.xlabel('H (A/m)')
plt.ylabel(r'Relative Permeability $\mu_r$')
plt.legend()

#%% OPERA, anhysteretic curves 
plt.figure(figsize=(6,4))
ct = 0
for filename in glob.glob('..//*.csv'):
        

# filename = '..//data//MSR//20240524//L5z_240524T144358_p_1Hz_2V_r_0Hz_0V_55s.csv'
        df = pd.read_csv(filename, comment='#')
        
        # sampling rate
        sr = 200
        
        # dictionary of layer thickness in m
        tkns_dict = {'1':0.004,
                  '2':0.003,
                  '3':0.003,
                  '5':0.002}
        
        # dictionary of layer side length in m
        sl_dict = {'1':3.5,
                   '2':3,
                   '3':2.6,
                   '5':2.4}
        
        # get layer number
        layer = str(int(os.path.basename(filename)[1]))
        
        # get orientation
        if layer in ('1', '5'):
            orientation = os.path.basename(filename)[2]
        else:
            orientation = ''
        
        I = np.asarray(df['Hantek (V)'])[sr:] / 0.01
        V = np.asarray(df['Pickup {} (V)'.format('L'+layer+orientation)])[sr:]
        
        V = invert_sgn_V(V, I, sr)
        
        I = remove_offset(I)[:sr+2]
        V = remove_offset(V)[:sr+2]
        
        tkns = tkns_dict[layer]
        sl = sl_dict[layer]
        
        # check edge coil status
        is_edge_coil = layer not in ('2', '3')
        
        # calculate flux length and cross sectional area based on edge coil status
        if is_edge_coil:
            fl = 4 * sl
            A = sl * tkns
        else: 
            fl = 2 * (1 + np.sqrt(2)) * sl
            A = 2 * sl * tkns
        
        
        
        # number of windings
        N_dri = 4*4
        N_ind = 1*4
        
        H = N_dri * I / fl
        H = H[:-1]
        B = 1 / (N_ind * A) * integrate.cumulative_trapezoid(V, dx=1/sr)
        B = remove_offset(B)
        M = B / scipy.constants.mu_0 - H
        
        
        H = remove_offset(H)
        B = remove_offset(B)
        M = remove_offset(M)
        
        H_increase_idx = np.argmin(H) # index from which H starts to increase  
        H_decrease_idx = np.argmax(H) # index from which H starts to decrease
        
        xmin, xmax = H[H_increase_idx], H[H_decrease_idx]
        
        # split into two arrays, dHdt > 0 and dHdt < 0
        if H_increase_idx < H_decrease_idx:  
            H_increase = H[H_increase_idx:H_decrease_idx]
            M_increase = M[H_increase_idx:H_decrease_idx]
            B_increase = B[H_increase_idx:H_decrease_idx]
            
            H_decrease = np.delete(H, np.arange(H_increase_idx, H_decrease_idx, 1))
            M_decrease = np.delete(M, np.arange(H_increase_idx, H_decrease_idx, 1))
            B_decrease = np.delete(B, np.arange(H_increase_idx, H_decrease_idx, 1))
            
            # sort decreasing arrays
            disc_idx = int(np.squeeze(np.where(abs(np.diff(H_decrease))>10)[0])) + 1
            
            H_decrease = sort_custom(H_decrease, disc_idx)
            M_decrease = sort_custom(M_decrease, disc_idx)
            B_decrease = sort_custom(B_decrease, disc_idx)
        
        else:
            H_decrease = H[H_decrease_idx:H_increase_idx]
            M_decrease = M[H_decrease_idx:H_increase_idx]
            B_decrease = B[H_decrease_idx:H_increase_idx]
        
            H_increase = np.delete(H, np.arange(H_decrease_idx, H_increase_idx, 1))
            M_increase = np.delete(M, np.arange(H_decrease_idx, H_increase_idx, 1))
            B_increase = np.delete(B, np.arange(H_decrease_idx, H_increase_idx, 1))
        
            # sort increasing arrays
            
            disc_idx = int(np.squeeze(np.where(abs(np.diff(H_increase))>10)[0])) + 1
            
            H_increase = sort_custom(H_increase, disc_idx)
            M_increase = sort_custom(M_increase, disc_idx)
            B_increase = sort_custom(B_increase, disc_idx)
        
        # generate anhysteresis bh file satisfying requirements for OPERA 3D by taking average of left and right branch
        label = 'Outer Door'
        
        B_s = 0.3
        a = 1
        h = 4.927
        b = 7.436
        
        popt, pcov = curve_fit(y_decrease, H_denoise(H_decrease, 'lin'), B_decrease, p0=(B_s, a, b, h, B_decrease[0]), maxfev=10000)
        # upper branch
        H_hys_de = np.linspace(H_decrease[0], -H_decrease[0], 100)
        B_hys_de = y_decrease(H_hys_de, *popt)
        
        # lower branch
        H_hys_in = np.copy(H_hys_de)[::-1]
        B_hys_in = y_increase(H_hys_in, *(popt[:4]), -popt[4])
        
        # truncate the first and last few points
        trunc_pts = 10
        H_hys_de = H_hys_de[trunc_pts:-trunc_pts]
        B_hys_de = B_hys_de[trunc_pts:-trunc_pts]
        
        H_hys_in = H_hys_in[trunc_pts:-trunc_pts]
        B_hys_in = B_hys_in[trunc_pts:-trunc_pts]
        
        # CubicSpline to get H(b)
        # of upper branch
        cs_de = CubicSpline(B_hys_de[::-1], H_hys_de[::-1])
        # of lower branch
        cs_in = CubicSpline(B_hys_in, H_hys_in)
        
        # sample at these B values
        B_anh = np.linspace(0, max(B_hys_in)+0.0*max(B_hys_in), 40)
        
        # sample
        H_anh = np.average(np.vstack([cs_de(B_anh), cs_in(B_anh)]), 0)
        H_anh[0] = 0
        
        
        plt.plot(H_hys_de, B_hys_de, color='Blue', label='DIMFH fit')
        plt.plot(H_hys_in, B_hys_in, color='Blue')
        plt.plot(H_decrease, B_decrease, '.', label='Experiment', color='Green')
        plt.plot(H_increase, B_increase, '.', color='Green')
        plt.plot(H_anh, B_anh, '--', color='Red', label='Anhysteretic Curve')
        plt.plot(-H_anh, -B_anh, '--', color='Red')
        # plt.annotate('', (-4, 0.246), xytext=(11.7, 0.246), arrowprops=dict(arrowstyle='<->'))
        
        # plt.plot(H_anh, B_anh/H_anh/scipy.constants.mu_0, label='L'+layer, color='C{}'.format(ct))
        # plt.plot(-H_anh, B_anh/H_anh/scipy.constants.mu_0, color='C{}'.format(ct))
        
        ct += 1
        plt.grid()
        plt.legend()
        plt.xlabel('H (A/m)')
        plt.ylabel('B (T)')
        # plt.xlim(-40, 40)
        plt.tight_layout()
        plt.show()

#%%
# save data
# export as tsv
matrix_aux = np.vstack([B_anh, H_anh])
matrix     = np.transpose(matrix_aux)
BH_df = pd.DataFrame(matrix)

BH_df.to_csv("..//BHdata//MSR_{}.tsv".format('L'+layer+orientation), sep='\t', index=False)

#%% extend data based on fit parameters

label = 'Outer Door'

B_s = 0.3
a = 1
h = 4.927
b = 7.436

popt, pcov = curve_fit(y_decrease, H_denoise(H_decrease, 'lin'), B_decrease, p0=(B_s, a, b, h, B_decrease[0]), maxfev=10000)
# upper branch
H_hys_de = np.linspace(500, -500, 2000)
B_hys_de = y_decrease(H_hys_de, *popt)

# lower branch
H_hys_in = np.copy(H_hys_de)[::-1]
B_hys_in = y_increase(H_hys_in, *(popt[:4]), -popt[4])

# truncate the first and last few points
trunc_pts = 50
H_hys_de = H_hys_de[trunc_pts:-trunc_pts]
B_hys_de = B_hys_de[trunc_pts:-trunc_pts]

H_hys_in = H_hys_in[trunc_pts:-trunc_pts]
B_hys_in = B_hys_in[trunc_pts:-trunc_pts]

# CubicSpline to get H(b)
# of upper branch
cs_de = CubicSpline(B_hys_de[::-1], H_hys_de[::-1])
# of lower branch
cs_in = CubicSpline(B_hys_in, H_hys_in)

# sample at these B values
B_anh = np.linspace(0, max(B_hys_in)+0.0*max(B_hys_in), 40)

# sample
H_anh = np.average(np.vstack([cs_de(B_anh), cs_in(B_anh)]), 0)
H_anh[0] = 0

plt.figure()
plt.plot(H_hys_de, B_hys_de, color='Blue')
plt.plot(H_hys_in, B_hys_in, color='Blue')
plt.plot(H_decrease, B_decrease, '.', label='Experiment', color='Green')
plt.plot(H_increase, B_increase, '.', color='Green')
plt.plot(H_anh, B_anh, '--', color='Red', label='Anhysteretic Curve')
plt.grid()
plt.legend()
plt.xlabel('H (A/m)')
plt.ylabel('B (T)')
plt.show()

#%%
# save data
# export as tsv
matrix_aux = np.vstack([B_anh, H_anh])
matrix     = np.transpose(matrix_aux)
BH_df = pd.DataFrame(matrix)

filename = "..//BHdata//MSR_{}_extended.tsv".format('L'+layer+orientation)

BH_df.to_csv(filename, sep='\t', index=False)

header = '40 1 0'

with open(filename, 'r+') as f:
    content = f.read()
    f.seek(0, 0)
    f.write(header + '\n' + content)
    f.close()




