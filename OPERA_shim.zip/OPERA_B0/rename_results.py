# Rename shim individual coil results
# Jul 2024

import glob, os

for file in glob.glob('*.res'):
    # later rename to same name as .res file
    name_new = os.path.basename(file)[:-4]
    
    fp = open(file)
    for i, line in enumerate(fp):
        if i == 290:
            # get initial name of corresponding results
            name_ini = line[-28:-6]
            
            # rename 
            os.rename('results//{}'.format(name_ini), 'results//{}.txt'.format(name_new))
    fp.close()
























