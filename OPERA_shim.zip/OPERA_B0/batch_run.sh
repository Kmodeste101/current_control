#!/bin/bash
source ~/.bashrc


for coilnum in {0..53}
do


newcomi="comi/make_coil"$coilnum".comi"

#operafea-modeller.exe projectfolder.comi /local /nowindow
if [ ! -f "models/"$newmodel".opc" ]; then
	echo $newcomi

	operafea-modeller.exe $newcomi /nowindow
fi

done
