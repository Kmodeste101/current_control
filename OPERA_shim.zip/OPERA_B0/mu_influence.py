# check influence of mu on field in the center
# Jul 2024

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import glob
import scipy
#%%
plt.figure()
for file in glob.glob('results//check//mu*00*'):
    table_df = pd.read_table(file, delim_whitespace=True, header=6, names=['x','Bx', 'By', 'Bz', 'Bmod'])
    table_df.columns = ['x','Bx', 'By', 'Bz', 'Bmod']
    
    plt.semilogy(table_df['x'], table_df['Bmod'],label=r'$\mu_r=$'+str(int(file[-11:-6])))

for file in glob.glob('results//check//*BH*'):
    table_df = pd.read_table(file, delim_whitespace=True, header=6, names=['x','Bx', 'By', 'Bz', 'Bmod'])
    table_df.columns = ['x','Bx', 'By', 'Bz', 'Bmod']
    
    plt.semilogy(table_df['x'], table_df['Bmod'], label=r'Nonlinear $\mu_r(H)$ (L5)')


def analytical_B(x, I, L):
    '''
    returns analytical solution of magnetic field along central axis of square loop of current
    '''
    return scipy.constants.mu_0*I*L/(4*np.pi)*(1/((x-1.1)**2+L**2/4))*(1/((x-1.1)**2+L**2/2)**(0.5)) 

x = np.linspace(-1.3, 1.3, 100)
# plt.semilogy(x, analytical_B(x, 1, 2*0.26), '*',label=r'Analytical $\mu_r=1$', markersize=2)

plt.legend()
plt.grid()
plt.xlabel('x [m]')
plt.ylabel('B [T]')
plt.show()



